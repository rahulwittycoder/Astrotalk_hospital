package com.astrotalk.hospital.entity;

public enum Status {
	ADMITTED, DISCHARGED;
}
