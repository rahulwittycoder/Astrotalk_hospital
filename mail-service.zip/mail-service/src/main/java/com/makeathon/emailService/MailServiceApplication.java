package com.makeathon.emailService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;

@SpringBootApplication
public class MailServiceApplication {

	@Autowired
	private EmailSenderService senderService;
	
	public static void main(String[] args) {
		SpringApplication.run(MailServiceApplication.class, args);
	}
	@EventListener(ApplicationReadyEvent.class)
	public void sendMail()
	{
		senderService.sendEmail("rahulmicromax64@gmail.com","Auto Generated Sample Email","Hello");
	}
}
