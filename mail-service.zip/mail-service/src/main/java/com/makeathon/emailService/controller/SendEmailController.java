package com.makeathon.emailService.controller;

public class SendEmailController {
	
}
