package com.expense.reimbursement.service.repository;

public interface ExpenseRepository {

}
