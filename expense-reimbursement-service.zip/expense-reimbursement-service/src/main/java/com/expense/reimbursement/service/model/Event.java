package com.expense.reimbursement.service.model;

public enum Event {
	VISA, Relocation, Others
}
