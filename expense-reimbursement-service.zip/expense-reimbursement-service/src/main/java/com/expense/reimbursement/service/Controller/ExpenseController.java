package com.expense.reimbursement.service.Controller;

import org.springframework.web.bind.annotation.RestController;

@RestController

public class ExpenseController {

}
