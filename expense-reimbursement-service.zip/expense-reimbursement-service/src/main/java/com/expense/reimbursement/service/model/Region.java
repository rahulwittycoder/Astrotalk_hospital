package com.expense.reimbursement.service.model;

public enum Region {
	Mysore, Ahmedabad, Bengaluru, Bhubaneswar, Chandigarh, Chennai, Coimbatore, Gurgaon, 
	Hubbali, Hyderabad, Indore, Jaipur, Kolkata, Mangalore, Mohali, Mumbai, Nagpur, Noida, Pune,
	Thiruvananthpuram, Vishakhapatnam
}
